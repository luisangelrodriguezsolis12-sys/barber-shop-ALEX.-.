// ============ Conexión a Firebase (base de datos real) ============
  const firebaseConfig = {
    apiKey: "AIzaSyDiLO2ikdGUcKwJH2nGwrquU_9uWn7a9XM",
    authDomain: "navaja-dorada-e6a0d.firebaseapp.com",
    projectId: "navaja-dorada-e6a0d",
    storageBucket: "navaja-dorada-e6a0d.firebasestorage.app",
    messagingSenderId: "741596424652",
    appId: "1:741596424652:web:a9bd42c1dd0ed42c6f9569",
    measurementId: "G-DNCR12JZ1T"
  };
  firebase.initializeApp(firebaseConfig);
  const db = firebase.firestore();

  // ============ Almacenamiento compartido (ahora guardado de verdad en Firestore) ============
  async function getShared(key, fallback){
    try{
      const snap = await db.collection('site_data').doc(key).get();
      if(snap.exists && snap.data().value !== undefined) return JSON.parse(snap.data().value);
      return fallback;
    }catch(e){ console.error('Error leyendo', key, e); return fallback; }
  }
  async function setShared(key, value){
    try{ await db.collection('site_data').doc(key).set({ value: JSON.stringify(value) }); }
    catch(e){ console.error('Error guardando', key, e); }
  }

  const DEFAULT_CONTENT = {
    shopName: 'La Navaja Dorada',
    pageTitle: 'La Navaja Dorada — Barbería',
    pageDescription: 'Reserva tu cita en La Navaja Dorada. Cortes clásicos, fade de precisión y arreglo de barba con navaja.',
    heroTitle: 'Cada corte se afila\ncon el mismo cuidado.',
    heroSubtitle: 'Cortes clásicos, fade de precisión y arreglo de barba con navaja. Reserva tu turno en menos de un minuto.',
    barberName: 'Rubén Alvarado',
    barberSpecialty: 'Fade, diseño y navaja clásica',
    barberBio: 'Más de 12 años de experiencia perfeccionando cortes clásicos y modernos, con especial atención al detalle en cada barba y acabado a navaja.',
    services: [
      {name:'Corte clásico', desc:'Tijera y máquina, acabado con navaja', price:180},
      {name:'Fade / degradado', desc:'Alta precisión, líneas marcadas', price:220},
      {name:'Arreglo de barba', desc:'Perfilado y navaja', price:150},
      {name:'Corte + barba', desc:'El paquete completo', price:320},
      {name:'Afeitado clásico', desc:'Navaja, toalla caliente, aceites', price:200},
      {name:'Corte niño', desc:'Hasta 12 años', price:130}
    ],
    address:'Av. Insurgentes Sur 1234, Col. Del Valle, CDMX',
    phone:'+52 55 1234 5678',
    hours:'Lun–Sáb, 10:00–20:00 · Dom cerrado',
    email:'hola@lanavajadorada.mx',
    whatsapp:'525512345678',
    facebookUrl:'',
    instagramUrl:'',
    waMessage:'Hola 👋, me gustaría agendar una cita en *{shop}* 💈✨. ¿Me podrían confirmar la disponibilidad?',
    barberPhoto:null,
    heroBackground:null,
    gallery:[
      {caption:'Fade clásico', image:null},
      {caption:'Barba tallada', image:null},
      {caption:'Pompadour', image:null},
      {caption:'Afeitado a navaja', image:null},
      {caption:'Corte texturizado', image:null},
      {caption:'Fade + diseño', image:null},
      {caption:'Corte niño', image:null},
      {caption:'Barba + bigote', image:null}
    ]
  };

  // Reduce y comprime una imagen antes de guardarla (las fotos se guardan como texto base64)
  function resizeImageFile(file, maxWidth=760, quality=0.72){
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const scale = Math.min(1, maxWidth / img.width);
          const canvas = document.createElement('canvas');
          canvas.width = img.width * scale;
          canvas.height = img.height * scale;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        };
        img.onerror = reject;
        img.src = reader.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  let content = null;

  function initials(name){
    return name.split(' ').filter(Boolean).slice(0,2).map(w=>w[0].toUpperCase()).join('');
  }

  function renderContent(){
    document.getElementById('navLogo').innerHTML = content.shopName.replace(/(\w+)$/, '<span>$1</span>');
    document.title = content.pageTitle || content.shopName;
    const descTag = document.getElementById('pageDescTag');
    if(descTag) descTag.setAttribute('content', content.pageDescription || '');
    document.getElementById('heroTitle').innerHTML = content.heroTitle.replace(/\n/g,'<br>');
    document.getElementById('heroSubtitle').textContent = content.heroSubtitle;

    const heroSection = document.getElementById('heroSection');
    if(content.heroBackground){
      heroSection.classList.add('has-bg');
      heroSection.style.backgroundImage = `url(${content.heroBackground})`;
    }else{
      heroSection.classList.remove('has-bg');
      heroSection.style.backgroundImage = '';
    }
    document.getElementById('barberName').textContent = content.barberName;
    document.getElementById('barberSpecialty').textContent = content.barberSpecialty;
    document.getElementById('barberBio').textContent = content.barberBio;

    const barberAvatar = document.getElementById('barberAvatar');
    barberAvatar.innerHTML = content.barberPhoto
      ? `<img src="${content.barberPhoto}" alt="Foto de ${content.barberName}">`
      : `<span id="barberInitials">${initials(content.barberName)}</span>`;

    document.getElementById('cAddress').textContent = content.address;
    document.getElementById('cPhone').textContent = content.phone;
    document.getElementById('cPhoneLink').href = 'tel:' + content.phone.replace(/[^\d+]/g,'');
    document.getElementById('mapFrame').src = 'https://www.google.com/maps?q=' + encodeURIComponent(content.address) + '&output=embed';
    document.getElementById('cHours').textContent = content.hours;
    document.getElementById('cEmail').textContent = content.email;
    document.getElementById('footerName').textContent = content.shopName;

    const waMessage = encodeURIComponent((content.waMessage || DEFAULT_CONTENT.waMessage).replace('{shop}', content.shopName));
    const waLink = 'https://wa.me/' + content.whatsapp.replace(/\D/g,'') + '?text=' + waMessage;
    ['waHeroBtn','waNavBtn','waContactBtn','waFloatBtn'].forEach(id => document.getElementById(id).href = waLink);
    const fbLink = content.facebookUrl || '#';
    const igLink = content.instagramUrl || '#';
    document.getElementById('fbNavBtn').href = fbLink;
    document.getElementById('igNavBtn').href = igLink;
    document.getElementById('fbContactBtn').href = fbLink;
    document.getElementById('igContactBtn').href = igLink;
    document.getElementById('fbFloatBtn').href = fbLink;
    document.getElementById('igFloatBtn').href = igLink;

    const servicesList = document.getElementById('servicesList');
    servicesList.innerHTML = '';
    content.services.forEach(s => {
      const row = document.createElement('div');
      row.className = 'service-row';
      row.innerHTML = `<div><div class="name">${s.name}</div><div class="desc">${s.desc}</div></div><div class="price">$${s.price}</div>`;
      servicesList.appendChild(row);
    });

    const serviceSelect = document.getElementById('service');
    serviceSelect.innerHTML = '<option value="">Selecciona...</option>' + content.services.map(s => `<option value="${s.name}">${s.name} — $${s.price}</option>`).join('');

    const galleryGrid = document.getElementById('galleryGrid');
    galleryGrid.innerHTML = '';
    const tilePairs = [['#2a2117','#171310'],['#241f22','#14120f'],['#22201a','#171310'],['#251c1c','#14120f'],['#1f231d','#14120f'],['#241f18','#171310'],['#221c22','#14120f'],['#231f1a','#171310']];
    content.gallery.forEach((g,i) => {
      const [a,b] = tilePairs[i % tilePairs.length];
      const tile = document.createElement('div');
      tile.className = 'gallery-tile';
      tile.style.setProperty('--tile-a', a);
      tile.style.setProperty('--tile-b', b);
      tile.innerHTML = (g.image ? `<img src="${g.image}" alt="${g.caption}">` : '') + `<span>${g.caption}</span>`;
      if(g.image){
        tile.addEventListener('click', () => openLightbox(g.image, g.caption));
      }
      galleryGrid.appendChild(tile);
    });
  }

  // ============ Reservas ============
  const allSlots = ['10:00','11:00','12:00','13:00','15:00','16:00','17:00','18:00','19:00'];
  let selectedSlot = null;
  let bookingsCache = [];
  const dateInput = document.getElementById('date');
  dateInput.min = new Date().toISOString().split('T')[0];

  async function loadBookings(){ bookingsCache = await getShared('bookings', []); }

  function renderSlots(){
    const slotsEl = document.getElementById('slots');
    const slotMsg = document.getElementById('slotMsg');
    slotsEl.innerHTML = '';
    slotMsg.className = 'msg';
    slotMsg.textContent = '';
    const chosenDate = dateInput.value;

    if(!chosenDate){
      slotsEl.innerHTML = '<div class="empty-note" style="grid-column:1/-1;">Elige una fecha para ver los horarios.</div>';
      return;
    }

    const isTaken = (time) => bookingsCache.some(b => b.date === chosenDate && b.time === time && b.status !== 'cancelada');
    const diaLleno = allSlots.every(isTaken);

    if(diaLleno){
      slotsEl.innerHTML = '<div class="empty-note" style="grid-column:1/-1;">Este día ya está lleno. Por favor elige otra fecha.</div>';
      slotMsg.className = 'msg error';
      slotMsg.textContent = 'No hay horarios disponibles para este día.';
      return;
    }

    allSlots.forEach(time => {
      const taken = isTaken(time);
      const el = document.createElement('div');
      el.className = 'slot' + (taken ? ' disabled' : '') + (selectedSlot === time ? ' selected' : '');
      el.textContent = time;
      if(!taken){ el.addEventListener('click', () => { selectedSlot = time; renderSlots(); }); }
      slotsEl.appendChild(el);
    });
  }
  dateInput.addEventListener('change', () => { selectedSlot = null; renderSlots(); });

  function buildConfirmationWaLink(name, phone, service, date, time){
    const msg = `✨ *Nueva cita confirmada — ${content.shopName}* ✨\n\n👤 Cliente: ${name}\n📞 Teléfono: ${phone}\n💈 Servicio: ${service}\n📅 Fecha: ${date}\n🕒 Hora: ${time}\n\n¡Gracias por reservar, nos vemos pronto! 🙌`;
    return 'https://wa.me/' + content.whatsapp.replace(/\D/g,'') + '?text=' + encodeURIComponent(msg);
  }

  document.getElementById('bookingForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const service = document.getElementById('service').value;
    const date = dateInput.value;
    const slotMsg = document.getElementById('slotMsg');
    const formMsg = document.getElementById('formMsg');
    slotMsg.textContent = ''; formMsg.textContent = '';
    if(!date){ formMsg.className='msg error'; formMsg.textContent='Elige una fecha.'; return; }
    if(!selectedSlot){ slotMsg.className='msg error'; slotMsg.textContent='Elige un horario disponible.'; return; }

    await loadBookings();
    const stillFree = !bookingsCache.some(b => b.date === date && b.time === selectedSlot && b.status !== 'cancelada');
    if(!stillFree){ slotMsg.className='msg error'; slotMsg.textContent='Ese horario se acaba de ocupar, elige otro.'; renderSlots(); return; }

    const newBooking = { id: Date.now().toString(36), name, phone, service, barber: content.barberName, date, time: selectedSlot, status: 'pendiente' };
    bookingsCache.push(newBooking);
    await setShared('bookings', bookingsCache);

    const waLinkConfirm = buildConfirmationWaLink(name, phone, service, date, selectedSlot);

    document.getElementById('ticketBody').innerHTML = `
      <p>¡Listo, ${name}! Tu cita quedó registrada para el <strong class="mono">${date}</strong> a las <strong class="mono">${selectedSlot}</strong>. En breve te confirmamos.</p>
      <a href="${waLinkConfirm}" target="_blank" class="btn btn-wa" style="width:100%; justify-content:center; margin-top:16px;">
        <i class="fa-brands fa-whatsapp"></i> Avisar por WhatsApp
      </a>`;
    formMsg.className='msg ok'; formMsg.textContent = '¡Solicitud enviada! Te esperamos.';
    e.target.reset(); selectedSlot = null; renderSlots();

    // Abre WhatsApp automáticamente con el mensaje ya listo, justo al generarse la confirmación
    window.open(waLinkConfirm, '_blank');
  });

  // ============ Reseñas ============
  let selectedStars = 5;
  const starPicker = document.getElementById('starPicker');
  function paintStars(){ [...starPicker.children].forEach(i => i.classList.toggle('active', parseInt(i.dataset.v) <= selectedStars)); }
  starPicker.addEventListener('click', (e) => { if(e.target.dataset.v){ selectedStars = parseInt(e.target.dataset.v); paintStars(); } });
  paintStars();
  function starString(n){ return '★'.repeat(n) + '☆'.repeat(5-n); }

  let reviewsCache = [];
  async function renderReviews(){
    reviewsCache = await getShared('reviews', [
      {id:'seed1', name:'Marco A.', stars:5, comment:'Excelente atención, el fade quedó perfecto.', date:'2026-06-20'},
      {id:'seed2', name:'Diego R.', stars:5, comment:'Un artista con la navaja.', date:'2026-06-15'},
      {id:'seed3', name:'Luis F.', stars:4, comment:'Muy buen servicio, un poco de espera.', date:'2026-06-10'}
    ]);
    const list = document.getElementById('reviewList');
    list.innerHTML = '';
    reviewsCache.slice().reverse().forEach(r => {
      const el = document.createElement('div');
      el.className = 'review-card';
      el.innerHTML = `<div class="rh"><strong>${r.name}</strong><span class="stars">${starString(r.stars)}</span></div><p>${r.comment}</p><div class="rd">${r.date}</div>`;
      list.appendChild(el);
    });
    const avg = reviewsCache.length ? (reviewsCache.reduce((s,r)=>s+r.stars,0)/reviewsCache.length).toFixed(1) : '—';
    document.getElementById('ratingText').textContent = `${avg} de 5 · ${reviewsCache.length} reseñas`;
    document.getElementById('barberRatingText').textContent = `${avg} · ${reviewsCache.length} reseñas`;
  }

  document.getElementById('reviewForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('rName').value.trim();
    const comment = document.getElementById('rComment').value.trim();
    const msg = document.getElementById('reviewMsg');
    reviewsCache.push({ id: Date.now().toString(36), name, stars: selectedStars, comment, date: new Date().toISOString().split('T')[0] });
    await setShared('reviews', reviewsCache);
    msg.className = 'msg ok'; msg.textContent = '¡Gracias por tu reseña!';
    e.target.reset(); selectedStars = 5; paintStars();
    await renderReviews();
  });

  // ============ Panel del dueño (contraseña solo del lado del cliente, demo) ============
  const ADMIN_PASS = 'barberia2026';
  const adminOverlay = document.getElementById('adminOverlay');
  document.getElementById('openAdmin').addEventListener('click', () => adminOverlay.classList.add('open'));
  document.getElementById('closeAdmin').addEventListener('click', () => adminOverlay.classList.remove('open'));
  adminOverlay.addEventListener('click', (e) => { if(e.target === adminOverlay) adminOverlay.classList.remove('open'); });

  document.getElementById('adminLoginBtn').addEventListener('click', async () => {
    const pass = document.getElementById('adminPass').value;
    const msg = document.getElementById('adminLoginMsg');
    if(pass !== ADMIN_PASS){ msg.textContent = 'Contraseña incorrecta.'; return; }
    msg.textContent = '';
    document.getElementById('adminLogin').style.display = 'none';
    document.getElementById('adminContent').style.display = 'block';
    renderTabContenido();
    await loadBookings(); renderTabCitas();
    renderTabResenas();
  });

  document.querySelectorAll('.admin-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      ['contenido','citas','resenas'].forEach(t => document.getElementById('tab'+t[0].toUpperCase()+t.slice(1)).style.display = 'none');
      const el = document.getElementById('tab'+tab.dataset.tab[0].toUpperCase()+tab.dataset.tab.slice(1));
      el.style.display = 'block';
    });
  });

  function renderTabContenido(){
    const el = document.getElementById('tabContenido');
    el.innerHTML = `
      <fieldset><legend>Negocio</legend>
        <div class="field"><label>Nombre del negocio</label><input id="edShopName" value="${content.shopName}"></div>
        <div class="field"><label>Título de la pestaña del navegador (SEO)</label><input id="edPageTitle" value="${content.pageTitle || ''}" placeholder="Ej. La Navaja Dorada — Barbería"></div>
        <div class="field"><label>Descripción para buscadores como Google (SEO)</label><textarea id="edPageDescription" placeholder="Una o dos frases que describan tu barbería">${content.pageDescription || ''}</textarea></div>
        <div class="field"><label>Título del hero</label><textarea id="edHeroTitle">${content.heroTitle}</textarea></div>
        <div class="field"><label>Subtítulo del hero</label><textarea id="edHeroSubtitle">${content.heroSubtitle}</textarea></div>
        <div class="field">
          <label>Imagen de fondo del hero (opcional)</label>
          <div class="avatar-upload">
            <img class="thumb-lg" id="heroBgPreview" src="${content.heroBackground || ''}" style="${content.heroBackground ? '' : 'display:none;'}">
            <div>
              <label class="file-btn"><i class="fa-solid fa-upload"></i> Subir foto<input type="file" id="heroBgInput" accept="image/*"></label>
              <button type="button" class="btn btn-sm btn-danger" id="removeHeroBgBtn" style="margin-top:6px; ${content.heroBackground ? '' : 'display:none;'}">Quitar foto de fondo</button>
            </div>
          </div>
          <div class="msg" id="heroBgMsg"></div>
        </div>
      </fieldset>
      <fieldset><legend>Barbero</legend>
        <div class="field"><label>Nombre</label><input id="edBarberName" value="${content.barberName}"></div>
        <div class="field"><label>Especialidad</label><input id="edBarberSpecialty" value="${content.barberSpecialty}"></div>
        <div class="field"><label>Biografía</label><textarea id="edBarberBio">${content.barberBio}</textarea></div>
        <div class="field">
          <label>Foto del barbero</label>
          <div class="avatar-upload">
            <img class="thumb-lg" id="barberPhotoPreview" src="${content.barberPhoto || ''}" style="${content.barberPhoto ? '' : 'display:none;'}">
            <label class="file-btn"><i class="fa-solid fa-upload"></i> Subir foto<input type="file" id="barberPhotoInput" accept="image/*"></label>
          </div>
          <div class="msg" id="barberPhotoMsg"></div>
        </div>
      </fieldset>
      <fieldset><legend>Servicios</legend>
        <div id="svcEditor"></div>
        <button type="button" class="btn btn-sm btn-outline" id="addSvcBtn">+ Agregar servicio</button>
      </fieldset>
      <fieldset><legend>Galería (fotos de cortes)</legend>
        <div id="galEditor"></div>
        <button type="button" class="btn btn-sm btn-outline" id="addGalBtn">+ Agregar foto</button>
      </fieldset>
      <fieldset><legend>Contacto y redes</legend>
        <div class="field"><label>Dirección</label><input id="edAddress" value="${content.address}"></div>
        <div class="row2">
          <div class="field"><label>Teléfono mostrado</label><input id="edPhone" value="${content.phone}"></div>
          <div class="field"><label>WhatsApp (solo números, con código de país)</label><input id="edWhatsapp" value="${content.whatsapp}"></div>
        </div>
        <div class="row2">
          <div class="field"><label>Horario</label><input id="edHours" value="${content.hours}"></div>
          <div class="field"><label>Email</label><input id="edEmail" value="${content.email}"></div>
        </div>
        <div class="row2">
          <div class="field"><label>Link de Facebook</label><input id="edFacebook" value="${content.facebookUrl || ''}" placeholder="https://facebook.com/tu-pagina"></div>
          <div class="field"><label>Link de Instagram</label><input id="edInstagram" value="${content.instagramUrl || ''}" placeholder="https://instagram.com/tu-cuenta"></div>
        </div>
        <div class="field">
          <label>Mensaje que se prellena al escribir por WhatsApp (usa {shop} para el nombre del negocio)</label>
          <textarea id="edWaMessage">${content.waMessage || DEFAULT_CONTENT.waMessage}</textarea>
        </div>
      </fieldset>
      <button class="btn" id="saveContentBtn">Guardar cambios</button>
      <div class="msg" id="saveContentMsg"></div>`;

    document.getElementById('heroBgInput').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if(!file) return;
      const msg = document.getElementById('heroBgMsg');
      msg.textContent = 'Procesando imagen...';
      try{
        const dataUrl = await resizeImageFile(file, 1400, 0.75);
        content.heroBackground = dataUrl;
        const preview = document.getElementById('heroBgPreview');
        preview.src = dataUrl; preview.style.display = 'block';
        document.getElementById('removeHeroBgBtn').style.display = 'inline-flex';
        msg.className='msg ok'; msg.textContent = 'Foto lista. Recuerda pulsar "Guardar cambios".';
      }catch(err){ msg.className='msg error'; msg.textContent = 'No se pudo procesar la imagen.'; }
    });
    document.getElementById('removeHeroBgBtn').addEventListener('click', () => {
      content.heroBackground = null;
      document.getElementById('heroBgPreview').style.display = 'none';
      document.getElementById('removeHeroBgBtn').style.display = 'none';
      document.getElementById('heroBgMsg').textContent = 'Se quitará al guardar cambios.';
    });
    document.getElementById('barberPhotoInput').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if(!file) return;
      const msg = document.getElementById('barberPhotoMsg');
      msg.textContent = 'Procesando imagen...';
      try{
        const dataUrl = await resizeImageFile(file, 500, 0.75);
        content.barberPhoto = dataUrl;
        const preview = document.getElementById('barberPhotoPreview');
        preview.src = dataUrl; preview.style.display = 'block';
        msg.className='msg ok'; msg.textContent = 'Foto lista. Recuerda pulsar "Guardar cambios".';
      }catch(err){ msg.className='msg error'; msg.textContent = 'No se pudo procesar la imagen.'; }
    });

    function renderSvcRows(){
      const wrap = document.getElementById('svcEditor');
      wrap.innerHTML = '';
      content.services.forEach((s, i) => {
        const row = document.createElement('div');
        row.className = 'svc-editor-row';
        row.innerHTML = `
          <input data-i="${i}" data-f="name" value="${s.name}" placeholder="Nombre">
          <input data-i="${i}" data-f="desc" value="${s.desc}" placeholder="Descripción">
          <input data-i="${i}" data-f="price" type="number" value="${s.price}" placeholder="Precio">
          <button type="button" class="btn btn-sm btn-danger" data-remove="${i}"><i class="fa-solid fa-trash"></i></button>`;
        wrap.appendChild(row);
      });
      wrap.querySelectorAll('input').forEach(inp => {
        inp.addEventListener('input', () => {
          const i = parseInt(inp.dataset.i); const f = inp.dataset.f;
          content.services[i][f] = f === 'price' ? parseFloat(inp.value)||0 : inp.value;
        });
      });
      wrap.querySelectorAll('button[data-remove]').forEach(btn => {
        btn.addEventListener('click', () => { content.services.splice(parseInt(btn.dataset.remove),1); renderSvcRows(); });
      });
    }
    renderSvcRows();
    document.getElementById('addSvcBtn').addEventListener('click', () => {
      content.services.push({name:'Nuevo servicio', desc:'', price:0}); renderSvcRows();
    });

    function renderGalRows(){
      const wrap = document.getElementById('galEditor');
      wrap.innerHTML = '';
      content.gallery.forEach((g, i) => {
        const row = document.createElement('div');
        row.className = 'img-editor-row';
        row.innerHTML = `
          <img class="thumb" src="${g.image || ''}" style="${g.image ? '' : 'background:var(--bg-alt);'}">
          <div>
            <input type="text" data-i="${i}" data-f="caption" value="${g.caption}" placeholder="Descripción (ej. Fade clásico)">
            <label class="file-btn"><i class="fa-solid fa-upload"></i> Subir foto<input type="file" accept="image/*" data-i="${i}" class="galFileInput"></label>
            <div class="msg" data-gmsg="${i}"></div>
          </div>
          <button type="button" class="btn btn-sm btn-danger" data-remove="${i}"><i class="fa-solid fa-trash"></i></button>`;
        wrap.appendChild(row);
      });
      wrap.querySelectorAll('input[type="text"]').forEach(inp => {
        inp.addEventListener('input', () => { content.gallery[parseInt(inp.dataset.i)].caption = inp.value; });
      });
      wrap.querySelectorAll('.galFileInput').forEach(inp => {
        inp.addEventListener('change', async (e) => {
          const i = parseInt(inp.dataset.i);
          const file = e.target.files[0];
          if(!file) return;
          const msgEl = wrap.querySelector(`[data-gmsg="${i}"]`);
          msgEl.textContent = 'Procesando imagen...';
          try{
            const dataUrl = await resizeImageFile(file, 700, 0.72);
            content.gallery[i].image = dataUrl;
            renderGalRows();
          }catch(err){ msgEl.className='msg error'; msgEl.textContent = 'No se pudo procesar la imagen.'; }
        });
      });
      wrap.querySelectorAll('button[data-remove]').forEach(btn => {
        btn.addEventListener('click', () => { content.gallery.splice(parseInt(btn.dataset.remove),1); renderGalRows(); });
      });
    }
    renderGalRows();
    document.getElementById('addGalBtn').addEventListener('click', () => {
      content.gallery.push({caption:'Nueva foto', image:null}); renderGalRows();
    });

    document.getElementById('saveContentBtn').addEventListener('click', async () => {
      content.shopName = document.getElementById('edShopName').value;
      content.pageTitle = document.getElementById('edPageTitle').value;
      content.pageDescription = document.getElementById('edPageDescription').value;
      content.heroTitle = document.getElementById('edHeroTitle').value;
      content.heroSubtitle = document.getElementById('edHeroSubtitle').value;
      content.barberName = document.getElementById('edBarberName').value;
      content.barberSpecialty = document.getElementById('edBarberSpecialty').value;
      content.barberBio = document.getElementById('edBarberBio').value;
      content.address = document.getElementById('edAddress').value;
      content.phone = document.getElementById('edPhone').value;
      content.whatsapp = document.getElementById('edWhatsapp').value;
      content.hours = document.getElementById('edHours').value;
      content.email = document.getElementById('edEmail').value;
      content.facebookUrl = document.getElementById('edFacebook').value;
      content.instagramUrl = document.getElementById('edInstagram').value;
      content.waMessage = document.getElementById('edWaMessage').value;
      const msg = document.getElementById('saveContentMsg');
      msg.className='msg'; msg.textContent='Guardando...';
      await setShared('siteContent', content);
      renderContent();
      msg.className='msg ok'; msg.textContent='Cambios guardados y publicados.';
    });
  }

  function renderTabCitas(){
    const el = document.getElementById('tabCitas');
    if(!bookingsCache.length){ el.innerHTML = '<div class="empty-note">Aún no hay citas reservadas.</div>'; return; }
    const sorted = [...bookingsCache].sort((a,b) => (a.date+a.time).localeCompare(b.date+b.time));
    el.innerHTML = '';
    sorted.forEach(b => {
      const row = document.createElement('div');
      row.className = 'admin-row';
      let actions = '';
      if(b.status === 'pendiente'){
        actions = `
          <button class="btn btn-sm" data-act="confirmar" data-id="${b.id}">Confirmar cita</button>
          <button class="btn btn-sm btn-danger" data-act="cancelar" data-id="${b.id}">Cancelar</button>`;
      }else if(b.status === 'confirmada'){
        actions = `
          <button class="btn btn-sm" data-act="completar" data-id="${b.id}">Marcar completada</button>
          <button class="btn btn-sm btn-danger" data-act="cancelar" data-id="${b.id}">Cancelar</button>`;
      }else{
        actions = `<button class="btn btn-sm btn-danger" data-act="eliminar" data-id="${b.id}">Eliminar</button>`;
      }
      row.innerHTML = `
        <div class="top-row"><strong>${b.name}</strong><span class="badge ${b.status}">${b.status}</span></div>
        <div>${b.service}</div>
        <div class="mono">${b.date} — ${b.time} · ${b.phone}</div>
        <div class="actions">${actions}</div>`;
      el.appendChild(row);
    });
    el.querySelectorAll('button[data-act]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const act = btn.dataset.act;
        if(act === 'eliminar'){
          bookingsCache = bookingsCache.filter(x => x.id !== btn.dataset.id);
        }else{
          const b = bookingsCache.find(x => x.id === btn.dataset.id);
          if(!b) return;
          if(act === 'confirmar') b.status = 'confirmada';
          else if(act === 'completar') b.status = 'completada';
          else if(act === 'cancelar') b.status = 'cancelada';
        }
        await setShared('bookings', bookingsCache);
        renderTabCitas(); renderSlots();
      });
    });
  }

  function renderTabResenas(){
    const el = document.getElementById('tabResenas');
    if(!reviewsCache.length){ el.innerHTML = '<div class="empty-note">Aún no hay reseñas.</div>'; return; }
    el.innerHTML = '';
    reviewsCache.slice().reverse().forEach(r => {
      const row = document.createElement('div');
      row.className = 'admin-row';
      row.innerHTML = `
        <div class="top-row"><strong>${r.name}</strong><span class="stars">${starString(r.stars)}</span></div>
        <div style="color:var(--muted);">${r.comment}</div>
        <div class="actions"><button class="btn btn-sm btn-danger" data-del="${r.id}">Eliminar</button></div>`;
      el.appendChild(row);
    });
    el.querySelectorAll('button[data-del]').forEach(btn => {
      btn.addEventListener('click', async () => {
        reviewsCache = reviewsCache.filter(r => r.id !== btn.dataset.del);
        await setShared('reviews', reviewsCache);
        renderTabResenas(); renderReviews();
      });
    });
  }

  // ============ Lightbox de galería ============
  const lightboxOverlay = document.getElementById('lightboxOverlay');
  function openLightbox(src, caption){
    document.getElementById('lightboxImg').src = src;
    document.getElementById('lightboxCaption').textContent = caption;
    lightboxOverlay.classList.add('open');
  }
  function closeLightbox(){ lightboxOverlay.classList.remove('open'); }
  lightboxOverlay.addEventListener('click', closeLightbox);
  document.getElementById('lightboxClose').addEventListener('click', (e) => { e.stopPropagation(); closeLightbox(); });

  // ============ Animación de aparición al hacer scroll ============
  function initReveal(){
    const targets = document.querySelectorAll('section > .section-head, section > .services, section > .barber-feature, section > .gallery, section > .reviews-wrap, section > .booking-wrap, section > .contact-wrap');
    targets.forEach(t => t.classList.add('reveal'));
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => { if(entry.isIntersecting){ entry.target.classList.add('visible'); io.unobserve(entry.target); } });
    }, { threshold: 0.12 });
    targets.forEach(t => io.observe(t));
  }

  // ============ Header transparente que se vuelve sólido al hacer scroll ============
  const headerEl = document.querySelector('header');
  function updateHeaderScroll(){ headerEl.classList.toggle('scrolled', window.scrollY > 40); }
  window.addEventListener('scroll', updateHeaderScroll);

  // ============ Inicialización ============
  (async () => {
    content = await getShared('siteContent', DEFAULT_CONTENT);
    renderContent();
    await loadBookings();
    renderSlots();
    await renderReviews();
    initReveal();
    updateHeaderScroll();
  })();
